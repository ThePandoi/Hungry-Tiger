package com.example.hungrytiger;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import hungry_tiger_.src.Load;
import hungry_tiger_.src.RestaLinkedList;

public class MainActivity extends AppCompatActivity {

    //RestaLinkedList restaurantArrayList = new RestaLinkedList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //restaurantArrayList = Load.load_restaurants(getApplicationContext());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*LinearLayout layout = findViewById(R.id.linear_layout); // get the linearLayout

        for(int x = 0; x < restaurantArrayList.size(); x++) {
            View restaurantButtonView = getLayoutInflater().inflate(R.layout.resturaunt_button, null);
            restaurantButtonView.setFocusable(false);
            restaurantButtonView.setFocusableInTouchMode(false);

            // set values of view in restaurant_button layout
            TextView restaurantNameTextView = restaurantButtonView.findViewById(R.id.restaurantName);
            restaurantNameTextView.setText(restaurantArrayList.searchbyindex(x).getplace().get_name());

            TextView restaurantTagsTextView = restaurantButtonView.findViewById(R.id.tags);
            restaurantTagsTextView.setText(restaurantArrayList.searchbyindex(x).getplace().get_tags().toString());

            TextView restaurantReviewTextView = restaurantButtonView.findViewById(R.id.review);
            restaurantReviewTextView.setText(String.valueOf(restaurantArrayList.searchbyindex(x).getplace().get_menu_item_rev_avrg()));



            // Add the inflated restaurant_button to LinearLayout
            layout.addView(restaurantButtonView);
        }*/

    }
}