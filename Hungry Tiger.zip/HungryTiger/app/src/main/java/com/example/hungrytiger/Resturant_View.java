package com.example.hungrytiger;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import hungry_tiger_.src.Load;
import hungry_tiger_.src.RestaLinkedList;
import hungry_tiger_.src.Sort;

//import hungry_tiger_.*;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Resturant_View#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Resturant_View extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    RestaLinkedList restaurantArrayList = new RestaLinkedList();

    public Resturant_View() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Resturant_View.
     */
    // TODO: Rename and change types and number of parameters
    public static Resturant_View newInstance(String param1, String param2) {
        Resturant_View fragment = new Resturant_View();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.search_bar_layout, container, false);

        // Add any additional functionality here
        // Find the SearchView widget
        SearchView searchView = view.findViewById(R.id.search_bar);

        // Set focus to the view
        //searchView.requestFocus();

        // Set a query listener on the SearchView widget
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
                    public boolean onQueryTextSubmit(String query) {
                // Call your search function with the search query
                //Sort.sortByRelevance(RL1, searchtags2);
                ArrayList<String> str = new ArrayList<>();
                String[] arr = query.split(" ");

                for(int x = 0; x < arr.length; x++) {
                    str.add(arr[x]);
                }

                restaurantArrayList = Sort.sortByRelevance(restaurantArrayList, str);
                adjustLinearLayout(view);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Do nothing
                return false;
            }
        });

        restaurantArrayList = Load.load_restaurants(getContext());

        adjustLinearLayout(view);

        return view;
    }

    public void adjustLinearLayout(View view) {
        LinearLayout layout = view.findViewById(R.id.linear_layout);

        layout.removeAllViews();

        for(int x = 0; x < restaurantArrayList.size(); x++) {
            View restaurantButtonView = getLayoutInflater().inflate(R.layout.resturaunt_button, layout, false);
            //restaurantButtonView.setFocusable(false);
            //restaurantButtonView.setFocusableInTouchMode(false);

            // set values of view in restaurant_button layout
            TextView restaurantNameTextView = restaurantButtonView.findViewById(R.id.restaurantName);
            String name = restaurantArrayList.searchbyindex(x).getplace().get_name();
            restaurantNameTextView.setText(name);
            name = name.replaceAll("\\s", "");
            name = name.toLowerCase();

            System.out.println(name);


            // Load bitmap from resource
            int resId = getContext().getResources().getIdentifier(name, "raw", getContext().getPackageName());
            InputStream is2 = getContext().getResources().openRawResource(resId);
            Bitmap bitmap = BitmapFactory.decodeStream(is2);

            // Generate mipmaps
            bitmap = bitmap.copy(bitmap.getConfig(), true);
            bitmap.setHasMipMap(true);
            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);

            // Set bitmap drawable to ImageView
            ImageView imageView = restaurantButtonView.findViewById(R.id.restaurantPicture);
            imageView.setImageDrawable(bitmapDrawable);

            try {
                is2.close();
            } catch(IOException e) {

            }


            TextView restaurantTagsTextView = restaurantButtonView.findViewById(R.id.tags);
            restaurantTagsTextView.setText(restaurantArrayList.searchbyindex(x).getplace().get_tags().toString());

            TextView restaurantReviewTextView = restaurantButtonView.findViewById(R.id.review);
            restaurantReviewTextView.setText(String.valueOf(restaurantArrayList.searchbyindex(x).getplace().get_menu_item_rev_avrg()));



            // Add the inflated restaurant_button to LinearLayout
            layout.addView(restaurantButtonView);
        }
    }

}